@extends('FrontEnd.layout.app')
@section('frontEnd-layour')
    <div class="container">
        <div class="row">
            <h1>OK</h1>
        </div>
    </div>
@endsection

<?php $__env->startSection('general-report'); ?>
    

<div class="container mt-5">
    <div class="row">
        <div class="col-8 mx-auto">
            <div class="card p-5">
                <div style="background: #1a05d6;color:#fff; padding:15px 10px; margin-bottom:10px;"">Update Cost Sheet</div>
                <form action="<?php echo e(route('update.cost',$costs->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <label for="add_money">Insert Add Money</label>
                    <input type="text" name="add_money" class="form-control mb-2" value="<?php echo e($costs->add_amout == 0 ? 0 :$costs->cost_amout); ?>">
                    
                    <label for="cost_money">Insert Cost Money</label>
                    <input type="text" name="cost_money" class="form-control mb-2" value="<?php echo e($costs->cost_amout == 0 ? 0 :$costs->cost_amout); ?>">

                    <button class="btn btn-primary w-100">Update</button>
                </form>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STUDENT\Desktop\my project\finalProjectETE\resources\views/Admin/blanceReport/editCost.blade.php ENDPATH**/ ?>
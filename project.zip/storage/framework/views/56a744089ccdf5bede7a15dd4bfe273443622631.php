<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
	<title>Attendance Record</title>
	<style>
		
			.even-row {
				background-color: #f2f2f2; /* Set the color for even rows */
			}

			.odd-row {
				background-color: #ffffff; /* Set the color for odd rows */
			}
    
	</style>
</head>
<body>
	<div class="row mb-3" style="display:flex;">
		<img style="width: 100px;" src="<?php echo e(public_path('custom_images/iiuc-logo.png')); ?>" alt="">
		
		<div class="contents" style="text-align:right; display:flex; margin-top:-100px; width:400px; margin-left:300px;">
			<span>International Islamic University Chittagong(IIUC)</span> <br>
			<span>Electronic & Telecommunication Engineering(ETE)</span> <br>
			<span><strong>Sunject Name :</strong> <?php echo e($SubjectName->subject_name); ?></span> <br>
			<span> <strong>Batch No :</strong> <?php echo e($batchWithStudent->batch_no); ?></span> <br>
			<span><strong>Download Date :</strong> <?php echo e($batchWithStudent->created_at->format('Y-M-d')); ?></span>
		</div>

	</div>
	<table class="table table-responsive bg-info">
		<tr style="background: rgb(92, 92, 94);text-align:center;">
			<td style="color:#fff; font-weight:bold; padding:10px;">SN</td>
			<td style="color:#fff; font-weight:bold; padding:10px;">Student id</td>
			<td style="color:#fff; font-weight:bold; padding:10px;">Student name</td>
			<td style="color:#fff; font-weight:bold; padding:10px;">Percentage</td>
		</tr>
		<?php if(isset($students)): ?>
			
	  
		<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php
				$isEven = $key % 2 === 0;
			?>
		<tr class="<?php echo e($isEven ? 'even-row' : 'odd-row'); ?>" style="text-align:center;">

			<td><?php echo e(++$key); ?></td>
			<td><?php echo e($student->std_id); ?></td>
			<td>
				<?php echo e($student->std_name); ?>

			</td>
			<td>
				<?php echo e($student->my_attendence_count .'/'. $totalAttendence); ?>

			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
	
	
	 </table>
</body>
</html><?php /**PATH C:\Users\STUDENT\Desktop\my project\finalProjectETE\resources\views/Admin/Attendance/attendancePdfData.blade.php ENDPATH**/ ?>
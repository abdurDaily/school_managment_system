
<?php $__env->startSection('frontEnd-layour'); ?>
    
<div class="event-area pt-130 pb-130">
    <div class="container">
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $searchBlog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-lg-4 col-md-6">
                    <div class="single-event mb-55 event-gray-bg">
                        <div class="event-img">
                            <a href="<?php echo e(route('singleBlog.details',$data->slug)); ?>"><img src="<?php echo e($data->image); ?>" alt=""></a>
                            <div class="event-date-wrap">
                                <span class="event-date"><?php echo e($data->created_at->format('d')); ?></span>
                                <span><?php echo e($data->created_at->format('M')); ?></span>
                            </div>
                        </div>
                        <div class="event-content">
                            <h3><a href="event-details.html"><?php echo e(Str::limit($data->title,40)); ?></a></h3>
                            <p>Pvolupttem accusantium doloremque laudantium, totam erspiciatis unde omnis iste natus error .</p>
                            <div class="event-meta-wrap">
                                <div class="event-meta">
                                    <i class="fa fa-location-arrow"></i>
                                    <span><?php echo e($data->CategoryBlog->title); ?></span>
                                </div>
                                <div class="event-meta">
                                    <i class="fa fa-clock-o"></i>
                                    <span><?php echo e($data->created_at->format('h,I,s')); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h4>No event post found</h4>
            <?php endif; ?>
        </div>
        <div class="pro-pagination-style text-center mt-25">
            <ul>
                <li>
                    
                </li>
            </ul>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('FrontEnd.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STUDENT\Desktop\my project\finalProjectETE\resources\views/FrontEnd/Blogs/searchBlog.blade.php ENDPATH**/ ?>
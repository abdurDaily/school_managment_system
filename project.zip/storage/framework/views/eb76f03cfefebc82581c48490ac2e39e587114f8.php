
<?php $__env->startSection('frontEnd-layour'); ?>
    <div class="container my-5">
        <div class="row">
            <?php $__currentLoopData = $teacherData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4">
                <img class="image" style="border: 3px solid #00a651;width: 300px; height:300px; border-radius:10px;" src="<?php echo $data->image; ?>" alt="">
            </div>
            <div class="col-lg-6" style="border-bottom: #00a651 3px solid">
                <div class="header">
                    <h1 style="color: #00a651;font-weight:bold;"><?php echo e($data->name); ?></h1>
                    <strong style="font-size: 20px"><?php echo e($data->designation); ?></strong>
                </div>

                <div class="details mt-4">
                    <i style="font-size: 20px;" class="fa fa-phone"><strong style="margin-left:10px;">Phone : </strong> <span><?php echo e($data->phone); ?></span></i> <br>
                    <i style="font-size: 20px;" class="fa fa-envelope"><strong style="margin-left:10px;">Email : </strong> <span><?php echo e($data->email); ?></span></i><br>
                    <a target="_blank" href="<?php echo e($data->website); ?>"><i style="font-size: 20px;" class="fa fa-globe"><strong style="margin-left:10px;">Protfolio Website</i></a>
                    
                    
                      <div class="edu-info mt-5">
                        <h3 style="color: #00a651;font-weight:bold;">Biography</h3>
                        <p style="font-size: 18px;">
                            <?php echo $data->biography; ?>

                        </p>
                      </div>

                            
                            <div class="edu-info mt-5">
                                <h3 style="color: #00a651;font-weight:bold;">Education Info.</h3>
                                <span style="font-size: 18px;">
                                    <?php echo $data->edu_info; ?>

                                </span>
                            </div>

                                    
                                    <div class="research mt-5">
                                        <h3 style="color: #00a651;font-weight:bold;">Research Area</h3>
                                        <span style="font-size: 18px;">
                                            <?php echo $data->research; ?>

                                        </span>
                                    </div>

                                            
                                            <div class="research mt-5">
                                                <h3 style="color: #00a651;font-weight:bold;">Teaching Subject's</h3>
                                                <span style="font-size: 18px;">
                                                    <?php echo $data->teaching_sub; ?>

                                                </span>
                                            </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('frontEndCSS'); ?>
    <style>
@media (min-width: 576px) and (max-width: 991.98px) {
            .header{
                margin-top: 40px !important;
            }
            .col-lg-4 > .image{
                margin: 0 auto;
            }
         }

    </style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('FrontEnd.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STUDENT\Desktop\my project\finalProjectETE\resources\views/FrontEnd/Teachers/teacherDetails.blade.php ENDPATH**/ ?>
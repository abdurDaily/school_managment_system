
<?php $__env->startSection('general-report'); ?>
<div class="grid columns-12 gap-6">
    <div class="g-col-12 g-col-xxl-9">
        <div class="grid columns-12 gap-6">
            <!-- BEGIN: General Report -->
            <div class="g-col-12 mt-8">
                <div class="intro-y d-flex align-items-center h-10">
                    <h2 class="fs-lg fw-medium truncate me-5">
                        General Report
                    </h2>
                    <a style="border: 1px solid rgb(110, 106, 106);" target="_blank" href="<?php echo e(route('invoice.index')); ?>" class="btn btn-light px-5 text-dark  ms-auto d-flex align-items-center text-theme-1 dark-text-theme-10"> <img style="width: 30px;" src="<?php echo e(asset('fonts_icon/file-pdf-solid.svg')); ?>" alt=""> <strong class="mr-5"> Download PDF</strong> </a>
                </div>
                <div class="grid columns-12 gap-6 mt-5">
                    <div class="g-col-12 g-col-sm-6 g-col-xl-3 intro-y">
                        <div class="report-box zoom-in">
                            <div class="box p-5">
                                <div class="d-flex">
                                    <i data-feather="shopping-cart" class="report-box__icon text-theme-10"></i> 
                                    <div class="ms-auto">
                                        <div class="report-box__indicator bg-theme-9 tooltip cursor-pointer" title="33% Higher than last month"> 33% <i data-feather="chevron-up" class="w-4 h-4 ms-0.5"></i> </div>
                                    </div>
                                </div>
                                <div class="report-box__total fs-3xl fw-medium mt-6"><?php echo e($availableAmount); ?></div>
                                <div class="fs-base text-gray-600 mt-1">Available Balance</div>
                            </div>
                        </div>
                    </div>

                    <?php $__currentLoopData = $totals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="g-col-12 g-col-sm-6 g-col-xl-3 intro-y">
                            <div class="report-box zoom-in">
                                <div class="box p-5">
                                    <div class="d-flex">
                                        <i data-feather="user" class="report-box__icon text-theme-9"></i> 
                                        <div class="ms-auto">
                                            <div class="report-box__indicator bg-theme-6 tooltip cursor-pointer" title="2% Lower than last month"> 2% <i data-feather="chevron-down" class="w-4 h-4 ms-0.5"></i></div>
                                            <span><?php echo e($cost->user->name); ?></span>
                                        </div>
                                    </div>
                                    
                                    <div class="report-box__total fw-medium mt-1"><span>Added Mony : </span> <strong style="font-size: 18px;"><?php echo e($cost->total_sales); ?> BDT</strong></div>
                                    <div class="report-box__total fw-medium mt-1"><span>cost Mony : </span> <strong style="font-size: 18px;"><?php echo e($cost->total_cost); ?> BDT</strong></div>
                                    <div class="report-box__total fw-medium mt-1"><span>update : </span> <strong style="font-size: 18px;"><?php echo e($cost->total_cost - $cost->total_sales); ?> BDT</strong></div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
            <!-- END: General Report -->

        </div>
    </div>
    <div class="g-col-12 g-col-xxl-3">
        <div class="border-start-xxl border-theme-5 dark-border-dark-3 mb-n10 pb-10">
            <div class="ps-xxl-6 grid grid-cols-12 gap-6">
                <!-- BEGIN: Transactions -->
                <div class="g-col-12 g-col-md-6 g-col-xl-4 g-col-xxl-12 mt-3 mt-xxl-8">
                    <div class="intro-x d-flex align-items-center h-10">
                        <h2 class="fs-lg fw-medium truncate me-5">
                            Transactions
                        </h2>
                    </div>
                    
                </div>
                <!-- END: Transactions -->

                
                
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STUDENT\Desktop\my project\finalProjectETE\resources\views/Admin/generalReport.blade.php ENDPATH**/ ?>
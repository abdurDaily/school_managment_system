
<?php $__env->startSection('report-table'); ?>
  <div class="container">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h1>All Teachers List</h1>
                </div>


                <div class="card-body table-responsive">
                    <table class="table table-striped table-hover">
                        <tr>
                            <th>SN</th>
                            <th>NAME</th>
                            <th>DASIGNATION</th>
                            <th>IMAGE</th>
                            <th>PHONE</th>
                            <th>EMAIL</th>
                            <th>WEVSITE</th>
                            <th>EDUCATION</th>
                            <th>REASEARCH</th>
                            <th>T.SUBJECTS</th>
                            <th>ACTION</th>
                        </tr>


                        <?php $__empty_1 = true; $__currentLoopData = $allTeachersData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e(++$key); ?></td>
                                <td><?php echo e($data->name); ?></td>
                                <td><?php echo e($data->designation); ?></td>
                                <td>
                                    <img width="80px" src="<?php echo e($data->image); ?>" alt="Image">
                                </td>
                                <td><?php echo e($data->phone); ?></td>
                                <td><?php echo e($data->email); ?></td>
                                <td><?php echo $data->website == null ? '<span class="text-danger">no data inserted!</span>' : $data->website; ?></td>
                                <td><?php echo $data->edu_info; ?></td>
                                <td><?php echo $data->research == null ? '<span class="text-danger">no data inserted!</span>' : $data->research; ?></td>
                                <td><?php echo $data->teaching_sub == null ? '<span class="text-danger">no data inserted!</span>' : $data->teaching_sub; ?></td>
                                <td>
                                    <div class="btn-group">
                                        <a href="<?php echo e(route('teacher.list.update', $data->id)); ?>" class="btn btn-primary btn-sm ">Edit</a>
                                        <a href="" class="btn btn-danger btn-sm ">Delete</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            
                        <?php endif; ?>
                    </table>
                </div>


            </div>
        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STUDENT\Desktop\my project\finalProjectETE\resources\views/Admin/Faculty/teachersList.blade.php ENDPATH**/ ?>
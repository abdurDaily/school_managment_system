
<?php $__env->startSection('report-table'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header" style="background: #2c09c9; color:#fff;padding:15px 10px">
                        <h1>Inseart Question</h1>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route("question.upload")); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?> 
                            <label for="semester">Select a Semester</label>
                            <select name="semester" id="semester" class="form-control mb-3">
                                <option value="" selected disabled>Select a Semester</option>
                                <?php $__currentLoopData = $semester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $responce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($responce->id); ?>"><?php echo e($responce->semester); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('semester')): ?>
                              <span class="text-danger"><?php echo e($errors->first('semester')); ?></span> <br>   
                            <?php endif; ?>



                            <label for="subjects">Select a Subject</label>
                            <select name="subjects" id="subjects" class="form-control">
                                <option selected disabled>Select a Subject</option>
                            </select>
                            <?php if($errors->has('subjects')): ?>
                              <span class="text-danger"><?php echo e($errors->first('subjects')); ?></span> <br>   
                            <?php endif; ?>

                            
                            <label for="sessions">Write Sessions Name & Year --(Autumn-2022)--</label>
                            <input name="sessions" id="sessions" type="text" class="form-control my-3" placeholder="--(Autumn-2022)--">
                            <?php if($errors->has('sessions')): ?>
                                <span class="text-danger"><?php echo e($errors->first('sessions')); ?></span> <br>   
                            <?php endif; ?>


                            <label for="pdf_file" class="mt-5">Insert a previous year question.(PDF) </label>
                            <input type="file" name="pdf_file" class="form-control mt-3" id="pdf_file">
                            <?php if($errors->has('pdf_file')): ?>
                                <span class="text-danger"><?php echo e($errors->first('pdf_file')); ?></span> <br>   
                            <?php endif; ?>
                            <button class="btn btn-primary w-100 mt-3">Upload</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>


    <?php $__env->startPush('ajax'); ?>
    <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script>
            $('#semester').on('change', function(){
                // alert('ok?')

                let semesterId = $(this).val()
                //console.log($semesterId)
                $.ajax({
                    url: `<?php echo e(route('select.subject')); ?>`,
                    method: 'GET',
                    data:{
                       id:semesterId
                    },
                    success: function(res){
                      let subject =JSON.parse(res)
                      let options = [];
                    //   console.log(subject)

                    subject.forEach(subjectResult => {
                        console.table(subjectResult)
                        let option = `<option value="${subjectResult.id}">${subjectResult.subject_name}</option>`
                        options.push(option)
                    });
                    $('#subjects').html(options)
                    },

                });
            })
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STUDENT\Desktop\my project\finalProjectETE\resources\views/Admin/Question/details.blade.php ENDPATH**/ ?>
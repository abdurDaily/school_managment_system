<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Error</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    
   <div class="container-fluid d-flex align-items-center justify-content-center" style="height: 100vh; background-color:#AFF0E4;">
      <img src="<?php echo e(asset('error/404.gif')); ?>" alt="">
   </div>
</body>
</html><?php /**PATH C:\Users\Abdur Rahman\Desktop\my project\finalProjectETE\resources\views/errors/404.blade.php ENDPATH**/ ?>
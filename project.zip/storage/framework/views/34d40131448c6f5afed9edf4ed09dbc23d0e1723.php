
<?php $__env->startSection('general-report'); ?>

<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header p-3 bg-info">
                    <h4>All Club List</h4>
                </div>
                <div class="card-body table-responsive">
                    <table class="table table-hover strip">
                        <tr>
                            <td>SN</td>
                            <td>Club Name</td>
                            <td>President</td>
                            <td>Logo</td>
                            <td>Fb Profile</td>
                            <td>Website</td>
                            <td>Created at</td>
                            <td>Action</td>
                        </tr>

                        <?php $__empty_1 = true; $__currentLoopData = $clubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e(++$key); ?></td>
                                <td><?php echo e($data->club_name); ?></td>
                                <td><?php echo e($data->presedent_name); ?></td>
                                <td>
                                    <img style="width: 100px" src="<?php echo e($data->image); ?>" alt="">
                                </td>
                                <td><?php echo e(Str::substr($data->fb_profile, 0, 15)); ?></td>
                                <td><?php echo e($data->website); ?></td>
                                <td><?php echo e($data->created_at); ?></td>
                                <td>
                                    <div class="btn-group">
                                        <a class="btn btn-primary btn-sm" href="<?php echo e(route('club.list.update',$data->id)); ?>">Edit</a>
                                        <a class="btn btn-danger btn-sm" href="<?php echo e(route('club.list.delete', $data->id)); ?>">Delete</a>
                                    </div>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <h4>No Club Data Found !</h4>
                        <?php endif; ?>

                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STUDENT\Desktop\my project\finalProjectETE\resources\views/Admin/club/clubList.blade.php ENDPATH**/ ?>

<?php $__env->startSection('report-table'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body" style="background: #4203a7; color:#fff;">
                        <h1>Add Subject</h1>
                    </div>

                    <div class="card-body p-5">
                        <form action="<?php echo e(route('insert.subject')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <label for="semester">Select a Semester</label>
                            <select name="semester" id="semester" class="form-control mb-5">
                                <option value="" selected disabled>Select a Semester</option>

                                <?php $__currentLoopData = $semester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->semester); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error"><strong class="text-danger mt-2"><?php echo e($message); ?></strong></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <br>


                            <label for="subject_name">insert course name with couse code </label>
                            <input name="subject_name" id="subject_name" type="text" class="form-control mb-3" placeholder="c programming (ETE-1101)">
                            <?php $__errorArgs = ['subject_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error"><strong class="text-danger mt-2"><?php echo e($message); ?></strong></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <button class="btn btn-primary w-100">submit</button>
                            <br>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdur Rahman\Desktop\my project\finalProjectETE\resources\views/Admin/Question/addsubject.blade.php ENDPATH**/ ?>
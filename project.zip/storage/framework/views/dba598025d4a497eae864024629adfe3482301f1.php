
<?php $__env->startSection('report-table'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header py-4" style="background: #1a047c; color:#fff;">
                        <h1>All Record</h1>
                    </div>

                    <div class="card-body">
                        <form action="<?php echo e(route('all.attendance.record')); ?>" method="GET">
                            <?php echo csrf_field(); ?> 
        
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="subject_id" class="mt-3">Select a Batch No</label>
                                    <select required name="subject_id" id="subject_id" class="form-control">
                                        <option  value="" selected disabled>Select a batch</option>
                                        <?php $__currentLoopData = $subjectId; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subjectData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($subjectData->id); ?>"><?php echo e($subjectData->subject_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['subject_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><strong><?php echo e($message); ?></strong></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
        
                                </div>
                                <div class="col-6">
                                    <label for="batch_id" class="mt-3">Select a Batch No</label>
                                    <select required name="batch_id" id="batch_id" class="form-control">
                                        <option  value="" selected disabled>Select a batch</option>
                                        <?php $__currentLoopData = $batchId; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batchData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($batchData->id); ?>"><?php echo e($batchData->batch_no); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['batch_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><strong><?php echo e($message); ?></strong></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        
                            <button class="btn btn-primary w-100 mt-5">Submit</button>
                         </form>


                         <table class="table table-responsive table-hover table-striped">
                            <tr>
                                <td>#</td>
                                <td>Student id</td>
                                <td>Student name</td>
                                <td>Percentage</td>
                            </tr>
                            <?php if(isset($students)): ?>
                                
                          
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                            <tr>
                                <td><?php echo e(++$key); ?></td>
                                <td><?php echo e($student->std_id); ?></td>
                                <td>
                                    <?php echo e($student->std_name); ?>

                                </td>
                                <td>
                                    <?php echo e($student->my_attendence_count .'/'. $totalAttendence); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>


                         </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('niceSelect2CSS'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" integrity="sha512-nMNlpuaDPrqlEls3IX/Q56H36qvBASwb3ipuo3MxeWbsQB1881ox0cRv7UPTgBlriqoynt35KjEwgGUeUXIPnw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<?php $__env->stopPush(); ?>
<?php $__env->startPush('niceSelect2'); ?>
<script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js" integrity="sha512-2ImtlRlf2VVmiGZsjm9bEyhjGW4dU7B6TNwh/hx/iSByxNENtj3WVE6o/9Lj4TJeVXPi4bnOIMXFIJJAeufa0A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script>
        $(document).ready(function() {
            $('#subject_id').select2();
            $('#batch_id').select2();
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STUDENT\Desktop\my project\finalProjectETE\resources\views/Admin/Attendance/allRecord.blade.php ENDPATH**/ ?>
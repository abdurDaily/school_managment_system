
<?php $__env->startSection('report-table'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header" style="background: #030a74; color:#fff; padding:15px;">
                        <h1>Attendance Sheet</h1>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-7 mx-auto p-3 mb-3" style="background: #1b3672;">
                                <form action="<?php echo e(route('check.present')); ?>" method="GET">
                                    <?php echo csrf_field(); ?> 
                                    <div class="row input-group mx-auto">
                                        <div class="col-9 mt-1">
                                            <select required name="batch_id" id="batch_id" class="form-control">
                                                <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->batch_no); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-3">
                                            <button class="btn btn-light" style="background: rgb(247, 243, 243)424;color:#000;">Submit</button>
                                        </div>
                                    </div>
                                </form> 
                            </div>



                            <?php if(isset($studentInfo)): ?>
                            <form action="<?php echo e(route('present.submit')); ?>" method="POST">
                               <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <input required name="date" type="date" class="form-control">
                                    <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><strong><?php echo e($message); ?></strong></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>


                                <div class="col-md-6">
                                    <label for="subject_id" class="mt-3">Select a Batch No</label>
                                    <select required name="subject_id" id="subject_id" class="form-control">
                                        <option  value="" selected disabled>Select a batch</option>
                                        <?php $__currentLoopData = $subjectId; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subjectData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($subjectData->id); ?>"><?php echo e($subjectData->subject_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <input name="check_id" type="hidden" value="<?php echo e(isset(request()->batch_id) ? request()->batch_id : ''); ?>">
                                </div>

                                <table class="table table-responsive table-striped table-hover mt-5">
                                    <tr>
                                        <th>SN</th>
                                        <th>Name</th>
                                        <th>Std id</th>
                                        <th>Status</th>
                                        
                                    </tr>
                                    <?php $__empty_1 = true; $__currentLoopData = $studentInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($detail->id); ?></td>
                                            <td><?php echo e($detail->std_name); ?></td>
                                            <td>
                                                <?php echo e($detail->std_id); ?>

                                            </td>
                                            <td>
                                                <div class="form-check form-switch">
                                                    <input name="isPresent[]" class="form-check-input"  value="<?php echo e($detail->id); ?>" type="checkbox" id="flexSwitchCheckDefault">
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>       
                                    <?php endif; ?>
                                </table>
                            </div>
                            <button class="btn btn-primary w-100 mt-5">Submit</button>
                        </form>
                        <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>





<?php $__env->startPush('niceSelect2CSS'); ?>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" integrity="sha512-nMNlpuaDPrqlEls3IX/Q56H36qvBASwb3ipuo3MxeWbsQB1881ox0cRv7UPTgBlriqoynt35KjEwgGUeUXIPnw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<?php $__env->stopPush(); ?>
<?php $__env->startPush('niceSelect2'); ?>
<script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js" integrity="sha512-2ImtlRlf2VVmiGZsjm9bEyhjGW4dU7B6TNwh/hx/iSByxNENtj3WVE6o/9Lj4TJeVXPi4bnOIMXFIJJAeufa0A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script>
    $(document).ready(function() {
    $('#batch_no').select2();
    $('#subject_id').select2();
    $('#batch_id').select2();
});

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STUDENT\Desktop\my project\finalProjectETE\resources\views/Admin/Attendance/present.blade.php ENDPATH**/ ?>

<?php $__env->startSection('general-report'); ?>
    

<div class="container">
    <div class="row">
            
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            
        <div class="col-12">
            <div class="card p-5 table-responsive">
                <table class="table table-striped table-hover">
                     <tr style="background: rgb(3, 58, 236); color:#fff;">
                        <th>SN</th>
                        <th>Author</th>
                        <th>Email</th>
                        <th>Add Money</th>
                        <th>Cost Money</th>
                        <th>Total</th>
                        <th>Create At</th>
                        <th>Update At</th>
                        <th>Action</th>
                      </tr>

                      <?php $__empty_1 = true; $__currentLoopData = $costSheet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                          <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($cost->user->name); ?></td>
                            <td><?php echo e($cost->user->email); ?></td>
                            <td><?php echo e($cost->add_amout == 0 ? '00 TK' : $cost->add_amout .'TK'); ?></td>
                            <td><?php echo e($cost->cost_amout == 0 ? '00 TK' : $cost->cost_amout.'TK'); ?></td>
                            <td style="background: rgb(72, 76, 88); color:#fff;"><?php echo e($cost->cost_amout + $cost->add_amout == 0 ? '00TK' : $cost->cost_amout + $cost->add_amout . 'TK'); ?></td>
                            <td><?php echo e($cost->created_at->format('d M, Y')); ?> </td>
                            <td><?php echo e($cost->updated_at->format('d M, Y')); ?> </td>
                            <td>
                                <div class="btn-group">
                                    <a href="<?php echo e(route('cost.edit',$cost->id)); ?>" class="btn btn-danger btn-sm text-light">Edit</a>
                                    <a href="<?php echo e(route('delete.cost',$cost->id)); ?>"class="btn btn-primary btn-sm text-light">Delete</a>
                                </div>
                            </td>
                          </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          
                      <?php endif; ?>
                </table>

                <br>
                <?php echo e($costSheet->links()); ?>


            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php $__env->startPush('pagination'); ?>
    <style>
        .pagination .page-item {
            margin: 0 3px;
        }
        .pagination span{
           background: rgb(30, 7, 230) !important;
           color: #fff !important;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STUDENT\Desktop\my project\finalProjectETE\resources\views/Admin/blanceReport/updateBalance.blade.php ENDPATH**/ ?>
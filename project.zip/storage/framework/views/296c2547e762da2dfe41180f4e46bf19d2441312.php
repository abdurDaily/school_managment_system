
<?php $__env->startSection('missingFitch'); ?>

<div class="container">
    <div class="row" style="margin: 50px 0">
             <div class="col-lg-4 text-lg-center my-5 my-lg-0">
                <img class="img-fluid" src="<?php echo e($teacherDetails->image); ?>" alt="">
             </div>

            <div class="col-lg-8">
                <h4><?php echo e($teacherDetails->name); ?></h4>
                <small><?php echo e($teacherDetails->designation); ?></small> <br>

                <br>
                
                <div class="contact">
                    <strong>Phone : </strong><small><a style="color: #000;" href="tel:<?php echo e($teacherDetails->phone); ?>"><?php echo e($teacherDetails->phone); ?></a></small> <br>
                    
                    <strong>Email : </strong><small><?php echo e($teacherDetails->email); ?></small> <br>

                    
                    <strong>
                        <a style="color: #000;" href="<?php echo e($teacherDetails->website); ?>">Facebook Profile</a>
                    </strong> <br> <br>

                    
                    <div class="edu-info">
                        <h4>Educational Information</h4> <br>
                        <?php echo $teacherDetails->edu_info; ?> 
                        <br>
                    </div>
                    

                    
                    <div class="edu-info">
                        <h4>Biography</h4>  <br>
                        <?php echo $teacherDetails->biography; ?>

                        <br>
                    </div>
                    

                    
                    <div class="edu-info">
                        <h4>Research</h4> <br>
                        <?php echo $teacherDetails->research; ?> <br>
                    </div>
                    

                    
                    <div class="edu-info">
                        <h4>Teaching Subject Info</h4>
                        <?php echo $teacherDetails->teaching_sub; ?>

                    </div>
                    

                </div>
            </div>
        
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('FrontEnd.secondaryLayout.navFoot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdur Rahman\Desktop\my project\finalProjectETE\resources\views/FrontEnd/secondaryLayout/teachers/teacherDetails.blade.php ENDPATH**/ ?>
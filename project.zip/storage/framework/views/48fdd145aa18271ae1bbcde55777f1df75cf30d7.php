
<?php $__env->startSection('report-table'); ?>
    <div class="container">
        <div class="row">
            <div class="col-10 mx-auto">
                <div class="card">
                    <div class="card-header" style="background: #330274;color:#fff;font-weight:bold;">
                        <h1>Insert Category Details</h1>
                    </div>

                    <div class="card-body">
                        <form action="<?php echo e(route('subcategory.data.insert')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <label for="title">
                                Insert a Blog Title
                            </label>
                            <input name="title" id="title" type="text" class="form-control" placeholder="------  title  -----">
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger"><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <br>


                            <label for="image">
                                Insert an Image
                            </label>
                            <input name="image" id="image" type="file" class="form-control" placeholder="------  image  -----">
                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger"><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <br>



                            <label for="category">Select a Parent Category</label>
                            <select required name="category" id="category" class="form-control mb-5">
                                <?php $__currentLoopData = $blogCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger"><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <br><br>



                            <label for="blog_details">Details About Post (Part - 1)</label>
                            <textarea placeholder="--- Detail Part 1 --" class="mt-2 form-control" id="blog_details" name="blog_details" id="blog_details" cols="30" rows="10"></textarea>
                            <?php $__errorArgs = ['blog_details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger"><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                            <label for="video" class="mt-3">Vidio Link</label>
                            <input name="video" id="video" type="text" class="form-control" placeholder="--- Youtube Link ---">

                            <button class="btn w-100 my-3" style="background: #330274;color:#fff;font-weight:bold;">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STUDENT\Desktop\my project\finalProjectETE\resources\views/Admin/Blogs/subCategory.blade.php ENDPATH**/ ?>

<?php $__env->startSection('general-report'); ?>
  <div class="container">
    <div class="row">
        <div class="col-lg-4 my-2 ">
            <div class="card shadow">
                <div class="card-header">
                 <h4>total users</h4>
                </div>
                <div class="card-body text-center">
                    <h1 style="font-size: 30px; font-weight:bold; color: blue;"><?php echo e($totalUsers); ?></h1>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4 my-2">
            <div class="card shadow">
                <div class="card-header">
                 <h4>Painding Users</h4>
                </div>
                <div class="card-body text-center">
                    <h1 style="font-size: 30px; font-weight:bold; color: blue;"><?php echo e($userPainding != 0 ? $userPainding : 'No'); ?></h1>
                </div>
            </div>
        </div>
        


        
        <div class="col-lg-4 my-2">
            <div class="card shadow">
                <div class="card-header">
                 <h4>Added Money</h4>
                </div>
                <div class="card-body text-center">
                    <h1 style="font-size: 30px; font-weight:bold; color: blue;"><?php echo e($addAmount); ?></h1>
                </div>
            </div>
        </div>
        


        
        <div class="col-lg-4 my-2">
            <div class="card shadow">
                <div class="card-header">
                 <h4>Cost Money</h4>
                </div>
                <div class="card-body text-center">
                    <h1 style="font-size: 30px; font-weight:bold; color: blue;"><?php echo e($costAmount); ?></h1>
                </div>
            </div>
        </div>
        


        
        <div class="col-lg-4 my-2">
            <div class="card shadow">
                <div class="card-header">
                 <h4>Available Money</h4>
                </div>
                <div class="card-body text-center">
                    <h1 style="font-size: 30px; font-weight:bold; color: blue;"><?php echo e($availableAmount); ?></h1>
                </div>
            </div>
        </div>
        
    </div>
    
    <div class="test" style="width:100%;">
        <?php echo $chart->container(); ?>

    </div>
  </div>


  
  <?php $__env->startPush('niceSelect2'); ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js" charset="utf-8"></script>
  <?php echo $chart->script(); ?>

  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STUDENT\Desktop\my project\finalProjectETE\resources\views/Admin/home/secondaryHome.blade.php ENDPATH**/ ?>

<?php $__env->startSection('report-table'); ?>
    <div class="container">
        <div class="row">
            <div class="col-10 mx-auto">
                <div class="card">
                    <div class="card-header" style="background: #330274;color:#fff;font-weight:bold;">
                        <h1>Insert Category For Blogs</h1>
                    </div>

                    <div class="card-body">
                        <form action="<?php echo e(route('category.data.insert')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <label for="category">
                                Insert a Category
                            </label>
                            <input name="category" id="category" type="text" class="form-control mt-3" placeholder="------Category-----">
                            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger"><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        


                            <button class="btn w-100 my-3" style="background: #330274;color:#fff;font-weight:bold;">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STUDENT\Desktop\my project\finalProjectETE\resources\views/Admin/Blogs/category.blade.php ENDPATH**/ ?>

<?php $__env->startSection('report-table'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="card">

                    <?php if(session()->has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('success')); ?>

                     </div>
                    <?php endif; ?>
                                    <?php if($message = Session::get('error-column')): ?>
                                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                            <strong><?php echo e($message); ?></strong> 
                                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"><img src="<?php echo e(asset('fonts_icon/circle-xmark-solid.svg')); ?>"  alt=""></button>
                                        </div>
                                    <?php endif; ?>

                    <div class="card-header" style="background: #041d61;color:#fff;padding:15px 20px;">
                        <h1>Previous Year Question's List </h1>

                        
                        

                        <?php if (! empty(trim($__env->yieldContent('success')))): ?>
                            <div class="alert alert-success">
                                <?php echo e(Session::get('success')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="card-body table-responsive">
                        <table class="table table-striped table-hover">
                            <tr>
                                <th>SN</th>
                                <th>Subject</th>
                                <th>Question's
                                <?php if($message = Session::get('error')): ?>

                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <strong><?php echo e($message); ?></strong> 
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"><img src="<?php echo e(asset('fonts_icon/circle-xmark-solid.svg')); ?>"  alt=""></button>
                                </div>
                                <?php endif; ?>

                                </th>
                                <th>Created_at</th>
                                <th>Action</th>
                            </tr>

                            <?php $__empty_1 = true; $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(++$key); ?></td>
                                    <td><?php echo e($data->subject_name); ?></td>
                                    <td>

                                    
                                        <div class="accordion accordion-flush" id="accordionFlushExample">
                                            
                                           
                                                <div class="accordion-item">
                                                <h2 class="accordion-header" id="flush-headingOne">
                                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse<?php echo e($data->id); ?>" aria-expanded="false" aria-controls="flush-collapseOne">
                                                  Previous Question's
                                                    </button>
                                                </h2>
                                                <?php $__empty_2 = true; $__currentLoopData = $data->detailsInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                <div id="flush-collapse<?php echo e($data->id); ?>" style="background: #f2e9e9; padding:5px;" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                                                    <div class="accordion-body">
                                                        <?php if(isset($detail->sessions )): ?>
                                                        <a target="_blank" href="<?php echo asset('storage/Questions/'.$detail->image); ?>"> <strong>Download</strong> <span class="text-danger"><?php echo e($detail->sessions); ?></span> <strong>PDF</strong>
                                                            <a class="btn btn-danger btn-sm" href="<?php echo e(route('question.update',$detail->id)); ?>"><span class="badge badge-light">Delete</span></a>
                                                        </a>

                                                        
                                                       
                                                        <?php endif; ?>
                                                    </div>
                                                </div> 
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                    <h1 class="text-danger mt-3">Not Upload Yeat!</h1>
                                                <?php endif; ?>
   
                                                </div>
   
                                          </div>
                                    </td>
                                    <td><?php echo e($data->created_at->format('d M, Y')); ?> </td>
                                  <td>
                                    <div class="btn-group">
                                        <a href="" id="dlt-btn"></a>
                                        <a class="dlt-btn btn btn-sm btn-danger" href="<?php echo e(route('delete.question.column',$data->id)); ?>">Delete</a>
                                    </div>
                                  </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <h1>no record found !</h1>
                            <?php endif; ?>

                        </table>
                        <br>
                        <?php echo e($details->links()); ?>

                    </div>
                </div>
            </div>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>




<?php $__env->startPush('pagination'); ?>
    <style>
        .pagination .page-item {
            margin: 0 3px;
        }
        .pagination span{
           background: rgb(30, 7, 230) !important;
           color: #fff !important;
        }
    </style>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('search'); ?>
<div class="search d-none d-sm-block">
    <form action="<?php echo e(route('search.question')); ?>" method="GET" role="search">
        <?php echo csrf_field(); ?>
        <input name="search" value="<?php echo e(Request::get('search')); ?>" type="search" class="search__input form-control border-transparent" placeholder="Search...">
        <i data-feather="search" class="search__icon dark-text-gray-300"></i> 
    </form>
</div>
<?php $__env->stopPush(); ?>



<?php $__env->startPush('niceSelect2CSS'); ?>
<link href="
https://cdn.jsdelivr.net/npm/sweetalert2@11.7.16/dist/sweetalert2.min.css
" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('sweetAleart2'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
<script src="
https://cdn.jsdelivr.net/npm/sweetalert2@11.7.16/dist/sweetalert2.all.min.js
"></script>

<script>

    $('.dlt-btn').on('click',function(e){

        e.preventDefault();
        
        Swal.fire({
        title: 'Are you sure?',
        text: "all record relevent this subject will be deleted",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = $(this).attr('href')
        }
        })
    })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STUDENT\Desktop\my project\finalProjectETE\resources\views/Admin/Question/detailslist.blade.php ENDPATH**/ ?>
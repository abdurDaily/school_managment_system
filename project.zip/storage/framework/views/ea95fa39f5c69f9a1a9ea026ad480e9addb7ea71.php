
<?php $__env->startSection('report-table'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12 mx-auto">
                <div class="card">
                    <div class="card-header">Search Results</div>
                </div>

                <div class="card-body table-responsive">
                    <table class="table table-striped table-hover">
                         <tr>
                            <th>SN</th>
                            <th>Semester</th>
                            <th>Subject Name</th>
                            <th>Created At</th>
                            <th>updated At</th>
                            <th>Action</th>
                         </tr>

                         <?php $__empty_1 = true; $__currentLoopData = $searchResult; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                         <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($list->semester->semester); ?></td>
                            <td><?php echo e($list->subject_name); ?></td>
                            <td><?php echo e($list->created_at->format('d M, Y')); ?></td>
                            <td><?php echo e($list->updated_at->format('d M, Y')); ?></td>
                            <td>
                                <div class="btn-group">
                                    <a href="<?php echo e(route('subject.edit',$list->id)); ?>" class="btn btn-danger btn-sm">Edit</a>
                                    <a href="" class="btn btn-primary btn-sm">Delete</a>
                                </div>
                            </td>
                         </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                             <div class="empty bg-danger text-light p-5">
                                <h1>Nothing Found !</h1>
                             </div>
                         <?php endif; ?>


                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('search'); ?>
<div class="search d-none d-sm-block">
    <form action="<?php echo e(route('search.subject')); ?>" method="GET" role="search">
        <?php echo csrf_field(); ?>
        <input name="search" value="<?php echo e(Request::get('search')); ?>" type="search" class="search__input form-control border-transparent" placeholder="Search...">
        <i data-feather="search" class="search__icon dark-text-gray-300"></i> 
    </form>
</div>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdur Rahman\Desktop\my project\finalProjectETE\resources\views/Admin/Question/searchlist.blade.php ENDPATH**/ ?>
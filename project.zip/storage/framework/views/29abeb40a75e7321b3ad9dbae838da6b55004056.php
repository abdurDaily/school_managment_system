
<?php $__env->startSection('general-report'); ?>
    <div class="container my-5">
        <div class="row">
            <div class="col-7 mx-auto" >
                <div class="card">
                    <div class="card-body bg-success text-light py-5">
                        <h1>Insert Your Consumtion With Proper Avidance</h1>
                    </div>
                    <div class="row my-3">
                        <div class="col-6 mx-auto">
                            <?php if($message = Session::get('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                               <strong><?php echo e($message); ?></strong>
                            </div>
                            <?php endif; ?> 
                        </div>
                    </div>
                    <form action="<?php echo e(route('insert.cost')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="card p-5">
                            

                            
                            


                            
                            <label for="cost">Add Balance</label>

                            <input type="number" class="form-control mt-3" name="add_cost" placeholder="add amount">
                            

                            <label for="cost">your cost Balance</label>
                            <input type="number" class="form-control mt-3" name="cost" placeholder="your cost amount.">
                            
                            <button class="btn btn-primary w-100 mt-3">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STUDENT\Desktop\my project\finalProjectETE\resources\views/Admin/blanceReport/insertBalance.blade.php ENDPATH**/ ?>
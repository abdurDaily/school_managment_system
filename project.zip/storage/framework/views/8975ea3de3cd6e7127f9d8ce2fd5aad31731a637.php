
<?php $__env->startSection('missingFitch'); ?>
    <div class="slider-area ">
        <div class="slider-height2 d-flex align-items-center">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="hero-cap hero-cap2 text-center">
                            <h2>Faculty's</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="team-area pt-160 pb-160">
        <div class="container">
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $allTeachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="single-team mb-30">
                            <div class="team-img">
                                <img src="<?php echo e($data->image); ?>" alt>

                                <ul class="team-social">
                                    <li><a href="<?php echo e($data->website); ?>"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="instructor.html#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="instructor.html#"><i class="fas fa-globe"></i></a></li>
                                </ul>
                            </div>
                            <div class="team-caption">
                                <h3><a href="<?php echo e(route('teacher.details', $data->slug)); ?>"><?php echo e($data->name); ?></a></h3>
                                <p><?php echo e($data->designation); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h4>No teachers data found..</h4>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('FrontEnd.secondaryLayout.navFoot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdur Rahman\Desktop\my project\finalProjectETE\resources\views/FrontEnd/secondaryLayout/teachers/teachersIndex.blade.php ENDPATH**/ ?>
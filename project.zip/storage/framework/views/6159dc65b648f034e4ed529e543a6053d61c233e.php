<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>please waite untile approve your requiest</h1>
</body>
</html><?php /**PATH C:\Users\STUDENT\Desktop\my project\finalProjectETE\resources\views/test/waitingPage.blade.php ENDPATH**/ ?>